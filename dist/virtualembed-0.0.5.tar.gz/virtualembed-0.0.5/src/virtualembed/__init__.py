from .virtualembed import VirtualEmbed, virtualembed_from_embed
